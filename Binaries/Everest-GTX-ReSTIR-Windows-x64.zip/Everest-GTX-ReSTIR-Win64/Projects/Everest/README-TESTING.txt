================================================================================
EVEREST — HYBRID HARDWARE RASTER + 3D-SDF GI + RT REFLECTIONS + FULL RT (WIN64)
================================================================================

1. QUICK START (WINDOWS x64, VULKAN 1.3 — GTX / RADEON / RTX)
   - Standalone Everest: launch `Projects\Everest\Everest.exe`
   - Full Frontier Hub : launch `Frontier.exe` and open the Everest project

2. LIGHTING MODES (LIVE ONE-CLICK SWITCHING)
   Click `[Hybrid]` or `[Full RT]` on the top-left Scene Viewport ribbon
   (or select `Render Pipeline -> Lighting Mode` in the Outliner/Inspector):

   [Mode 0 — Hybrid (Default on Launch, `HybridSDF_RT`)]
     - Primary & Glazing : Hardware triangle rasterization (`SurfaceRaster` +
                           `ForwardRaster`) with Reversed-Z depth, hardware
                           `ddx`/`ddy` mipmap + metallic flake derivatives,
                           and exact per-pixel screen motion vectors.
     - Direct Lighting   : Deterministic 3-cascade hardware `D32_SFLOAT` solar
                           shadow maps (`ShadowRaster`, 3x3 Vogel PCF) + analytic
                           Karis rectangular area & clustered luminaires
                           (`DirectRadiance`) — ZERO DI Monte Carlo noise.
     - Diffuse GI        : Half-res (`TraceScale = 2`, 1/4 pixels) 1 cosine ray/px
                           marching hardware 3D textures (`Sampler3D` `R16F`)
                           4-cascade SDF clipmaps ONLY (`DistanceTraversal`) +
                           `SurfaceCards` multi-bounce radiosity, denoised by
                           `VarianceTemporal` + `VarianceWavelet` + joint
                           bilateral upsampling.
     - Reflections       : Raytraced Heitz VNDF reflections (`ReflectionTraversal`)
                           against Two-Level 8-Wide CWBVH triangles + `SurfaceCards`,
                           denoised by `VarianceTemporal` + `VarianceWavelet`.

   [Mode 1 — Full Raytracing (2nd Option, `FullRaytracing`)]
     - Primary, Direct (RIS + Beer-Lambert shadow rays), Full-Res Diffuse GI,
       and VNDF Specular Reflections all raytraced against Two-Level 8-Wide
       CWBVH triangles + `SurfaceCards`, denoised by `VarianceTemporal` +
       `VarianceWavelet`.

3. FLIGHT CONTROLS & TELEMETRY LOGS
   - Hold Right Mouse Button (RMB) in Scene Viewport + WASD / Q / E (+ Shift 3x)
   - Press `R` while flying (or click `Reset Cam`) to restore default viewpoint
   - Telemetry logs written automatically next to `Everest.exe`:
       * `EverestDiagnostics.log` (GPU/driver info, SPIR-V sizes, summary stats)
       * `EverestPerformance.csv` (per-frame GPU pass breakdown + active mode)
================================================================================

--------------------------------------------------------------------------------
UPDATE - WebGPU Demo 1:1 Renderer Parity Build
--------------------------------------------------------------------------------
- Fast Preview ("fast Blinn"): GPU-side ACES present (PresentPreviewView);
  the old per-frame GPU->CPU readback + CPU tonemap + re-upload round trip
  (which capped preview at ~10 FPS) is gone. Swapchain is now MAILBOX/3-image.
- Hybrid (GTX): ReSTIR GI (temporal + spatial reservoir reuse, Jacobian + 1/Z)
  over half-res hardware 3D SDF + surface cards; physical Rayleigh/Mie/ozone
  sky; display TAA (YCoCg variance-clamped) + depth-occluded lens flare.
- Full RT (RTX): same ReSTIR GI + TAA, candidates traced against the CWBVH at
  half-res 1 ray/px (demo parity workload; previously full-res up to 4 rays/px,
  which is why RT dropped to ~60 FPS where the web demo held 90-110 FPS).
Rename note: the previous build announced a 44s black-box debug package; this
zip supersedes it.
